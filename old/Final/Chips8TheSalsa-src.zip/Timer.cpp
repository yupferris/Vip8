#include "Timer.h"

unsigned int Timer::GetTime()
{
	return timeGetTime();
}
