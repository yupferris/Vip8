#ifndef __COMMON_H__
#define __COMMON_H__

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

#include <Windows.h>
#include <GL/gl.h>

#include "Exception.h"

#endif
