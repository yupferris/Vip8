#ifndef __TIMER_H__
#define __TIMER_H__

#include "Common.h"

class Timer
{
public:
	static unsigned int GetTime();
};

#endif
